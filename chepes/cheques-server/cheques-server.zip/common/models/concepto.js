"use strict";

module.exports = function (Concepto) {
  Concepto.consultar = (where, order, cb) => {
    const ds = Concepto.app.dataSources.SQLServerContinuo.connector;
    let query =
      `select * from conceptos` +
      (where !== undefined ? ` where ${where}` : ``) +
      (order !== undefined ? ` order by ${order}` : ``);

    ds.query(query, [], async (error, data) => {
      if (error) cb(error);
      else {
        try {
          cb(null, data);
        } catch (err) {
          cb(err);
        }
      }
    });
  };

  Concepto.remoteMethod("consultar", {
    accepts: [
      { arg: "where", type: "string", required: true },
      { arg: "order", type: "string" },
    ],
    returns: { type: "array", root: true },
    http: { verb: "get" },
  });

  Concepto.crear = (object, cb) => {
    const ds = Concepto.app.dataSources.SQLServerContinuo.connector;
    let query = `insert into conceptos descripcion = ${object.descricion} return id`;

    ds.query(query, [], async (error, data) => {
      if (error) cb(error);
      else {
        try {
          cb(null, data);
        } catch (err) {
          cb(err);
        }
      }
    });
  };

  Concepto.remoteMethod("crear", {
    accepts: [
      { arg: "where", type: "string", required: true },
      { arg: "order", type: "string" },
    ],
    returns: { type: "array", root: true },
    http: { verb: "get" },
  });
};
