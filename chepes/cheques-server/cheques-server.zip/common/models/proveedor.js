"use strict";

module.exports = function (Proveedor) {
  Proveedor.consultar = (cb) => {
    const ds = Proveedor.app.dataSources.SQLServerContinuo.connector;
    let query = `select * from Proveedores`;

    ds.query(query, [], async (error, data) => {
      if (error) cb(error);
      else {
        try {
          cb(null, data);
        } catch (err) {
          cb(err);
        }
      }
    });
  };

  Proveedor.remoteMethod("consultar", {
    accepts: [],
    returns: { type: "array", root: true },
    http: { verb: "get" },
  });
};
