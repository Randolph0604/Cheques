import React, { useState, useEffect } from "react";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import {
  TextField,
  Grid,
  Paper,
  Select,
  FormControl,
  MenuItem,
  Button,
  IconButton,
} from "@mui/material";
import SaveIcon from "@mui/icons-material/Save";
import ClearAllIcon from "@mui/icons-material/ClearAll";
import DeleteForeverIcon from "@mui/icons-material/DeleteForever";
import EditIcon from "@mui/icons-material/Edit";
import "./PaymentConcepts.css";
import {
  postPaymentConcepts,
  deletePaymentConcepts,
  putPaymentConcept,
} from "../../helpers/helpers";
import logo from "../../logo.svg";
import { Consultar } from "../../common/server/funcionesServidor";

const PaymentConcept = () => {
  const [modificando, setModificando] = useState({
    idPayment: 0,
    description: "",
    status: "",
  });

  const [data, setData] = useState(undefined);

  useEffect(() => {
    consultar();
  }, []);

  useEffect(() => {
    setModificando({
      idPayment: 0,
      description: "",
      status: "",
    });
  }, [data]);

  const consultar = async () => {
    setData(await Consultar(`api/PaymentConcepts`, null, null, undefined));
  };

  const handleInputs = (value, name) => {
    let copiaData = JSON.parse(JSON.stringify(modificando));
    setModificando({ ...copiaData, [name]: value });
    console.log({ value, name });
  };

  const onSubmit = async (e) => {
    if (modificando.idPayment === 0) {
      await postPaymentConcepts(modificando);
    } else {
      await putPaymentConcept(modificando)
        .then((res) => console.log(res))
        .catch((err) => console.log(err));
    }

    consultar();
    onClear();
  };

  const onModificar = ({ idPayment, description, status }) => {
    setModificando({
      idPayment: idPayment,
      description: description,
      status: status,
    });
  };

  const onDelete = async (id) => {
    if (window.confirm("Are you sure you want to delete it?")) {
      await deletePaymentConcepts(id)
        .then((res) => console.log(res))
        .then(() => {
          consultar();
          onClear();
        })
        .catch((err) => console.log(err));
    }
  };

  const onClear = () => {
    setModificando({
      idPayment: 0,
      description: "",
      status: "",
    });
  };

  return (
    <div className="container">
      <Paper variant="outlined" className="paper">
        <img src={logo} className="img App-logo" alt="img" />
        <Grid container spacing={2} className="grid">
          <Grid item xs={12} fullWidth>
            <TextField
              fullWidth
              id="outlined-password-input"
              label="Id"
              type="text"
              name="idPayment"
              value={
                modificando
                  ? modificando.idPayment
                    ? modificando.idPayment
                    : undefined
                  : undefined
              }
              onChange={(e) => handleInputs(e.currentTarget.value, "idPayment")}
              disabled
              style={{ display: "none" }}
            />
          </Grid>

          <Grid item xs={6}>
            <TextField
              fullWidth
              id="outlined-password-input"
              label="Description*"
              type="text"
              name="description"
              value={modificando.description}
              onChange={(e) =>
                handleInputs(e.currentTarget.value, "description")
              }
            />
          </Grid>

          <Grid item xs={6}>
            {/* <InputLabel id="demo-simple-select-label">Status</InputLabel> */}
            <Select
              fullWidth
              labelId="demo-simple-select-label"
              id="demo-simple-select"
              label="status"
              name="status"
              value={modificando.status}
              onChange={(e) => handleInputs(e.target.value, "status")}
            >
              <MenuItem value="A">Activo</MenuItem>
              <MenuItem value="I">Inactivo</MenuItem>
            </Select>
          </Grid>

          <Grid item xs={6}>
            <FormControl fullWidth>
              <Button
                className="btnSave"
                type="button"
                variant="contained"
                size="large"
                endIcon={<SaveIcon />}
                onClick={() => onSubmit()}
              >
                Save
              </Button>
            </FormControl>
          </Grid>

          <Grid item xs={6}>
            <FormControl fullWidth>
              <Button
                className="btnSave"
                onClick={() => onClear()}
                type="button"
                color="inherit"
                variant="contained"
                size="large"
                endIcon={<ClearAllIcon />}
              >
                Clear
              </Button>
            </FormControl>
          </Grid>
        </Grid>
      </Paper>

      {data ? (
        <>
          <TableContainer
            className="table"
            component={Paper}
            sx={{ maxWidth: 700 }}
          >
            <Table aria-label="simple table">
              <TableHead>
                <TableRow>
                  <TableCell className="title">ID&nbsp;(IdPayment)</TableCell>
                  <TableCell className="title">Description</TableCell>
                  <TableCell className="title">Status</TableCell>
                  <TableCell className="title">Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {data.map((data) => (
                  <TableRow
                    key={data.idPayment}
                    sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                    className="hover"
                  >
                    <TableCell component="th" scope="row">
                      {data.idPayment}
                    </TableCell>
                    <TableCell>{data.description}</TableCell>
                    <TableCell>{data.status}</TableCell>
                    <TableCell>
                      <IconButton
                        onClick={() => onModificar(data)}
                        style={{ color: "#ff9100" }}
                        aria-label="upload picture"
                        component="span"
                      >
                        <EditIcon />
                      </IconButton>
                      <IconButton
                        onClick={() => onDelete(data.idPayment)}
                        color="error"
                        aria-label="upload picture"
                        component="span"
                      >
                        <DeleteForeverIcon />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </>
      ) : null}
    </div>
  );
};

export default PaymentConcept;
