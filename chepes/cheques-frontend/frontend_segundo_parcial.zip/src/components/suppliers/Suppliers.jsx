import React, { useState, useEffect } from "react";
// import { PaymentConcepts } from "../../hooks/hooks";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import {
  TextField,
  Grid,
  Paper,
  Select,
  FormControl,
  MenuItem,
  // InputLabel/,
  Button,
  IconButton,
} from "@mui/material";
import SaveIcon from "@mui/icons-material/Save";
import ClearAllIcon from "@mui/icons-material/ClearAll";
import DeleteForeverIcon from "@mui/icons-material/DeleteForever";
import EditIcon from "@mui/icons-material/Edit";
import "./Suppliers.css";
import {
  postSuppliers,
  putSuppliers,
  deleteSuppliers,
} from "../../helpers/helpers";
import logo from "../../logo.svg";
import { Consultar } from "../../common/server/funcionesServidor";
import MensajeAlerta from "../../common/mensajeAlerta/mensajeAlerta";

const Suppliers = () => {
  const [modificando, setModificando] = useState({
    idSupplier: null,
    name: "",
    personType: "",
    identification: "",
    balance: 0,
    status: "",
  });

  const [data, setData] = useState(undefined);

  useEffect(() => {
    consultar();
  }, []);

  useEffect(() => {
    setModificando({
      idSupplier: null,
      name: "",
      personType: "",
      identification: "",
      balance: 0,
      status: "",
    });
  }, [data]);

  const consultar = async () => {
    setData(await Consultar(`api/proveedors/consultar`, null, null, undefined));
  };

  const handleInputs = (value, name) => {
    let copiaData = JSON.parse(JSON.stringify(modificando));
    if (name === 'identification' && isNaN(value)) return MensajeAlerta("error", "Solo se aceptan numeros en el campo de cédula")
    if (name === 'identification' && value.length > 11) return;
    setModificando({ ...copiaData, [name]: value });
  };

  const onSubmit = async (e) => {
    if (!modificando.idSupplier) {
      if (modificando.identification) return MensajeAlerta("error", "Digitar cédula");
      await postSuppliers(modificando);
    } else {
      await putSuppliers(modificando)
        .then((res) => console.log(res))
        .catch((err) => console.log(err));
    }

    consultar();
    onClear();
  };

  const onModificar = ({
    idSupplier,
    name,
    personType,
    identification,
    balance,
    status,
  }) => {
    setModificando({
      idSupplier: idSupplier,
      name: name,
      personType: personType,
      identification: identification,
      balance: balance,
      status: status,
    });
  };

  const onDelete = async (id) => {
    if (window.confirm("Are you sure you want to delete it?")) {
      await deleteSuppliers(id)
        .then((res) => console.log(res))
        .then(() => {
          consultar();
          onClear();
        })
        .catch((err) => console.log(err));
    }
  };

  const onClear = () => {
    setModificando({
      idSupplier: null,
      name: "",
      personType: "",
      identification: "",
      balance: 0,
      status: "",
    });
  };

  return (
    <div className="container">
      <Paper variant="outlined" className="paper">
        <img src={logo} className="img App-logo" alt="img" />
        <Grid container spacing={2} className="grid">
          <Grid item xs={12} fullWidth>
            <TextField
              fullWidth
              id="outlined-password-input"
              label="idSuppliers"
              type="text"
              name="idSuppliers"
              value={
                modificando.idSuppliers
              }
              onChange={(e) => handleInputs(e.currentTarget.value, "idSuppliers")}
              disabled
              style={{ display: "none" }}
            />
          </Grid>

          <Grid item xs={6}>
            <TextField
              fullWidth
              id="outlined-password-input"
              label="Nombre*"
              type="text"
              name="name"
              value={modificando.name}
              onChange={(e) =>
                handleInputs(e.currentTarget.value, "name")
              }
            />
          </Grid>
          <Grid item xs={6}>
            <TextField
              fullWidth
              id="outlined-password-input"
              label="Rnc/Cedula*"
              type="text"
              name="identification"
              value={modificando.identification}
              onChange={(e) =>
                handleInputs(e.currentTarget.value, "identification")
              }
            />
          </Grid>

          <Grid item xs={6}>
            {/* <InputLabel id="demo-simple-select-label">Status</InputLabel> */}
            <Select
              fullWidth
              labelId="demo-simple-select-label"
              id="demo-simple-select"
              label="status"
              name="status"
              value={modificando.status}
              onChange={(e) => handleInputs(e.target.value, "status")}
            >
              <MenuItem value="A">Activo</MenuItem>
              <MenuItem value="I">Inactivo</MenuItem>
            </Select>
          </Grid>
          <Grid item xs={6}>
            {/* <InputLabel id="demo-simple-select-label">Status</InputLabel> */}
            <Select
              fullWidth
              labelId="demo-simple-select-label"
              id="demo-simple-select"
              label="Tipo de Persona"
              name="personType"
              value={modificando.personType}
              onChange={(e) => handleInputs(e.target.value, "personType")}
            >
              <MenuItem value="J">Juridica</MenuItem>
              <MenuItem value="F">Fisica</MenuItem>
            </Select>
          </Grid>

          <Grid item xs={6}>
            <FormControl fullWidth>
              <Button
                className="btnSave"
                type="button"
                variant="contained"
                size="large"
                endIcon={<SaveIcon />}
                onClick={() => onSubmit()}
              >
                Save
              </Button>
            </FormControl>
          </Grid>

          <Grid item xs={6}>
            <FormControl fullWidth>
              <Button
                className="btnSave"
                onClick={() => onClear()}
                type="button"
                color="inherit"
                variant="contained"
                size="large"
                endIcon={<ClearAllIcon />}
              >
                Clear
              </Button>
            </FormControl>
          </Grid>
        </Grid>
      </Paper>

      {data ? (
        <>
          <TableContainer
            className="table"
            component={Paper}
            sx={{ maxWidth: 900 }}
          >
            <Table aria-label="simple table">
              <TableHead>
                <TableRow>
                  <TableCell className="title">ID&nbsp;(IdSuplidor)</TableCell>
                  <TableCell className="title">Nombre</TableCell>
                  <TableCell className="title">RNC/Cedula</TableCell>
                  <TableCell className="title">Balance</TableCell>
                  <TableCell className="title">Tipo de Persona</TableCell>
                  <TableCell className="title">Estado</TableCell>
                  <TableCell className="title">Acciones</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {data.map((data) => (
                  <TableRow
                    key={data.idSupplier}
                    sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                    className="hover"
                  >
                    <TableCell component="th" scope="row">
                      {data.idSupplier}
                    </TableCell>
                    <TableCell>{data.Nombre}</TableCell>
                    <TableCell>{data.Tipo_Persona}</TableCell>
                    <TableCell>{data.balance}</TableCell>
                    <TableCell>{data.personType}</TableCell>
                    <TableCell>{data.status}</TableCell>
                    <TableCell>
                      <IconButton
                        onClick={() => onModificar(data)}
                        style={{ color: "#ff9100" }}
                        aria-label="upload picture"
                        component="span"
                      >
                        <EditIcon />
                      </IconButton>
                      <IconButton
                        onClick={() => onDelete(data.idSupplier)}
                        color="error"
                        aria-label="upload picture"
                        component="span"
                      >
                        <DeleteForeverIcon />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </>
      ) : null}
    </div>
  );
};

export default Suppliers;
