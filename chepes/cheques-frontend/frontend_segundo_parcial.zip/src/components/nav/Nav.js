import * as React from 'react';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import IconButton from '@mui/material/IconButton';
import HomeIcon from '@mui/icons-material/Home';
import './Nav.css';
import { Link } from 'react-router-dom';


const Nav = () => {

    return (
        <Box sx={{ flexGrow: 1 }}>
            <AppBar position="static">
                <Toolbar>
                    <IconButton color="inherit">
                        <HomeIcon style={{ 'width': '50px', 'height': '50px' }} />
                    </IconButton>
                    <Link to="/paymentConcepts" style={{ 'textDecoration': 'none', 'color': '#fff' }}>
                        <IconButton color="inherit">
                            <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
                                Payments Concepts
                            </Typography>
                        </IconButton>
                    </Link>

                    <Link to="/accountingEntries" style={{ 'textDecoration': 'none', 'color': '#fff' }}>
                        <IconButton color="inherit">
                            <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
                                Account Entries
                            </Typography>
                        </IconButton>
                    </Link>
                    <Link to="/Documents" style={{ 'textDecoration': 'none', 'color': '#fff' }}>
                        <IconButton color="inherit">
                            <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
                                Documents
                            </Typography>
                        </IconButton>
                    </Link>
                    <Link to="/Suppliers" style={{ 'textDecoration': 'none', 'color': '#fff' }}>
                        <IconButton color="inherit">
                            <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
                                Suppliers
                            </Typography>
                        </IconButton>
                    </Link>

                </Toolbar>
            </AppBar>
        </Box>
    )
}

export default Nav
