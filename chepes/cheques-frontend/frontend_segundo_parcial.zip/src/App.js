import "./App.css";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./components/home/Home";
import Nav from "./components/nav/Nav";
import Suppliers from "./components/suppliers/Suppliers";
import Documents from "./components/documents/Documents";
import PaymentConcept from "./components/paymentConcepts/PaymentConcepts";
import AccountingEntries from "./components/accountingEntries/accountingEntries";
import { CssBaseline } from "@material-ui/core";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import "bootstrap/dist/css/bootstrap.min.css";

function App() {
  return (
    <Router>
      <CssBaseline />
      <ToastContainer />
      <Nav />
      <>
        <Routes>
          <Route exact path="/" element={<Home />} />
          <Route exact path="/paymentConcepts" element={<PaymentConcept />} />
          <Route
            exact
            path="/accountingEntries"
            element={<AccountingEntries />}
          />
          <Route exact path="/Suppliers" element={<Suppliers />} />
          <Route exact path="/Documents" element={<Documents />} />
        </Routes>
      </>
    </Router>
  );
}

export default App;
